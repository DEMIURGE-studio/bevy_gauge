(function() {
    var implementors = Object.fromEntries([["bevy_gauge",[["impl&lt;T: Component&gt; QueryFilter for <a class=\"struct\" href=\"bevy_gauge/dirty/struct.Dirty.html\" title=\"struct bevy_gauge::dirty::Dirty\">Dirty</a>&lt;T&gt;"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[186]}
(function() {
    var implementors = Object.fromEntries([["bevy_gauge",[["impl SystemParam for <a class=\"struct\" href=\"bevy_gauge/stat_accessor/struct.StatAccessor.html\" title=\"struct bevy_gauge::stat_accessor::StatAccessor\">StatAccessor</a>&lt;'_, '_&gt;"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[208]}
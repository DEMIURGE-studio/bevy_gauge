window.ALL_CRATES = ["bevy_gauge"];
//{"start":21,"fragment_lengths":[12]}
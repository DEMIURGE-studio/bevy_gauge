(function() {
    var implementors = Object.fromEntries([["bevy_gauge",[["impl&lt;'w, 's&gt; ReadOnlySystemParam for <a class=\"struct\" href=\"bevy_gauge/stat_accessor/struct.StatAccessor.html\" title=\"struct bevy_gauge::stat_accessor::StatAccessor\">StatAccessor</a>&lt;'w, 's&gt;<div class=\"where\">where\n    Query&lt;'w, 's, &amp;'static mut <a class=\"struct\" href=\"bevy_gauge/stats_component/struct.Stats.html\" title=\"struct bevy_gauge::stats_component::Stats\">Stats</a>&gt;: ReadOnlySystemParam,</div>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[463]}
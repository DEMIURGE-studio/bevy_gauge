(function() {
    var implementors = Object.fromEntries([["bevy_gauge",[["impl&lt;'a&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/alloc/string/trait.ToString.html\" title=\"trait alloc::string::ToString\">ToString</a> for <a class=\"struct\" href=\"bevy_gauge/stat_addressing/struct.StatPath.html\" title=\"struct bevy_gauge::stat_addressing::StatPath\">StatPath</a>&lt;'a&gt;"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[342]}
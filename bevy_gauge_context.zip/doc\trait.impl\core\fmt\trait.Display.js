(function() {
    var implementors = Object.fromEntries([["bevy_gauge",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/fmt/trait.Display.html\" title=\"trait core::fmt::Display\">Display</a> for <a class=\"enum\" href=\"bevy_gauge/stat_error/enum.StatError.html\" title=\"enum bevy_gauge::stat_error::StatError\">StatError</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[298]}